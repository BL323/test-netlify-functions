const { GREET_MESSAGE } = process.env;

exports.handler = async (event, context) => {
  return {
    statusCode: 200,
    body: GREET_MESSAGE
  };
};